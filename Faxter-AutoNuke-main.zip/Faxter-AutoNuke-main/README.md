Code By YoungAOS

Instalacion 
Linux:
```npm install python3```
```npm install pip```
```pip install discord```
```npm install git```
``` git clone https://github.com/youngaos/AutoNuke/tree/main```
``` cd AutoNuke```
``` python3 main.py``` (CREO QUE ERA HACI XD)

Replit: 
```
Solo copias el main.py y el archivo **.json** creas un repositorio en replit (python)lo pegas y runeas el code```
